#ifndef RESULT_H
#define RESULT_H

#include "student.h"

void calculateResult(struct Students *s);
void assignGrade(struct Students *s);

#endif