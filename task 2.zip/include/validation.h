#ifndef VALIDATION_H
#define VALIDATION_H

#include "student.h"

int isValidID(char id[], struct Students s[], int count);
int isValidName(char name[]);
int isValidMarks(int m);

#endif