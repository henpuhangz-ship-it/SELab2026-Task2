#ifndef REPORT_H
#define REPORT_H

#include "student.h"

void report(struct Students s[], int n);
void Stats(struct Students s[], int n);

#endif